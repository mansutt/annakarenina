+++
title = "Code and Results"
date = 2022-09-05T00:53:35+02:00
weight = 2
chapter = true
pre = "<b>2. </b>"
+++

### Part 2

# Code and Results

Performing different analyses on the text using Python and visualizing the results.