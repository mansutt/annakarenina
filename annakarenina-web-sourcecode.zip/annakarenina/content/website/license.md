---
title: "License"
date: 2022-09-05T19:37:35+02:00
draft: false
weight: 2
---

All code for this project can be used and modified according to [GNU General Public License v3.0](https://github.com/mansutt/annakarenina/blob/main/LICENSE). The same conditions apply to all content on this website.

This website uses no cookies or any form of tracking at all.

Logo designed by Julia Wang.