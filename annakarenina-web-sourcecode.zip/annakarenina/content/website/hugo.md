---
title: "Hugo"
date: 2022-09-05T01:02:36+02:00
draft: false
weight: 1
---

This website was created using [Hugo](https://gohugo.io) with the [Learn](https://github.com/matcornic/hugo-theme-learn) theme. After an initial learning period, Hugo offers an easy-to-use way to create lightweight websites. All the pages on this site are written as markdown files and the entire source code of the website can be found in the GitHub repository.