---
title: "Text"
date: 2022-09-05T01:00:46+02:00
draft: false
weight: 1
---

In order to perform quantitative analyses on a text, the text first has to be acquired in a machine-readable format. In the case of _Anna Karenina_, the text is available in multiple editions and languages on [Project Gutenberg](https://www.gutenberg.org/ebooks/search/?query=anna+karenina&submit_search=Go%21). Here, the [most downloaded English version](https://www.gutenberg.org/ebooks/1399), translated from the Russian original by Constance Garnett was used.