+++
title = "Basics"
date = 2022-09-05T00:50:36+02:00
weight = 1
chapter = true
pre = "<b>1. </b>"
+++

### Part 1

# Text & Preprocessing

Acquiring the text and performing preprocessing for further analyses.